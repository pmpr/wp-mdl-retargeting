<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9506bb9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; class CartEvent extends Common { }
