<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9506bb9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
