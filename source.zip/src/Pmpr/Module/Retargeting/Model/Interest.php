<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da7d01899             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Interest extends Common { public function register() { $this->muuwuqssqkaieqge(__('Interests', PR__MDL__RETARGETING))->guiaswksukmgageq(__('Interest', PR__MDL__RETARGETING))->saemoowcasogykak(IconInterface::wieeamqomamwgucs); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::woicooamkeqiaemo)->gswweykyogmsyawy(__('Product', PR__MDL__RETARGETING)))->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::kasiqisuaessmwua)->gswweykyogmsyawy(__('Score', PR__MDL__RETARGETING))); parent::uwmqacgewuauagai(); } }
