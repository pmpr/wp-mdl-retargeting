<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da7d01899             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; class CartEvent extends Common { }
