<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c8cd2d0be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class PageEvent extends Common { public function register() { $this->muuwuqssqkaieqge(__('Page Events', PR__MDL__RETARGETING))->guiaswksukmgageq(__('Page Event', PR__MDL__RETARGETING))->saemoowcasogykak(IconInterface::wieeamqomamwgucs); } }
