<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c43b0ef124             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; class CartEvent extends Common { }
