<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da7d01899             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\ORM\Model; class Visit extends Model { public function register() { } }
