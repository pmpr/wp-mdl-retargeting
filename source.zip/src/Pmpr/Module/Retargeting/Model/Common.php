<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6953da7d01899             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Utility\VisitorTracker\Model\Visitor; abstract class Common extends Model { public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(Constants::cmcqgcgqyckmiggk)->gswweykyogmsyawy(__('Visitor', PR__MDL__RETARGETING))->wuuqgaekqeymecag(Visitor::class)); parent::uwmqacgewuauagai(); } }
