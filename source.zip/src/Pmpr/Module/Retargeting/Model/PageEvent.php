<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9506bb9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class PageEvent extends Common { public function register() { $this->muuwuqssqkaieqge(__('Page Events', PR__MDL__RETARGETING))->guiaswksukmgageq(__('Page Event', PR__MDL__RETARGETING))->saemoowcasogykak(IconInterface::wieeamqomamwgucs); } }
