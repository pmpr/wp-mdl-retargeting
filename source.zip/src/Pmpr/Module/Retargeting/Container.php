<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c8cd2d0be             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
