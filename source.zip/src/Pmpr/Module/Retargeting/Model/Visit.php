<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             695a9506bb9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Retargeting\Model; use Pmpr\Common\Foundation\ORM\Model; class Visit extends Model { public function register() { } }
